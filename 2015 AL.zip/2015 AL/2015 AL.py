# 2015 A/L


index_no=0
while (index_no != -1):
    index_no=int(input("index_no:-"))
    
    if (index_no != -1):
        mark_1=int(input("Marks:-"))
        mark_2=int(input("Marks:-"))
        mark_3=int(input("Marks:-"))

        record1=index_no,mark_1,mark_2,mark_3
        record=str(record1)
        file=open("Mark.txt","a")
        file.write(record)
        file.close()
    else:
        index_no=-1


