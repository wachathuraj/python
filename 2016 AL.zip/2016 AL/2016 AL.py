# 2016 A/L
price=0
price_list={"ft1":10,"ft2":12,"ft3":15,"ft4":10,"ft5":25,"ft6":45,"ft7":50,"ft8":25,"ft9":10,"ft10":12}
no_item=str(input("input item code & no_item:-"))
item=no_item.split(",")
for i in item:
    x=i.split("*")


